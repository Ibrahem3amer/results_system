<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<h1><?php echo e($student->name); ?></h1>
	<h1><?php echo e($student->code); ?></h1>
	<h1><?php echo e($student->class); ?></h1>
	<?php $subjects = json_decode($student->subjects); ?>
	<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject => $score): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<h2><?php echo e($subject); ?> ==> <?php echo e($score); ?></h2>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	<hr />
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>