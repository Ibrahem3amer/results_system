<!DOCTYPE html>
<html lang="en">
	<head>
	    <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
	    <meta name="description" content="">
	    <meta name="author" content="">
	    <title>Higher Energy Institute</title>
	    <link href="https://fonts.googleapis.com/css?family=Amiri" rel="stylesheet"> 
	    <!-- Bootstrap Core CSS -->
	    <link href="<?php echo e(URL::to('/css/bootstrap.min.css')); ?>" rel="stylesheet">
	    <!-- Custom CSS -->
		<link href = "<?php echo e(URL::to('/css/styles.css')); ?>" rel = "stylesheet">
		<link href = "<?php echo e(URL::to('/css/font-awesome.min.css')); ?>" rel = "stylesheet">
	</head>
	<body>
		<div id = "wrapper" class = "container-fluid"> 
		</div>
			<a href="<?php echo e(URL::to('/')); ?>">
				<img src="<?php echo e(URL::to('/images/logo.jpg')); ?>" class="img-responsive logo" />
			</a>
			<div class="input-holder">
			    <h3>الكود: <?php echo e($user->code); ?></h3>
			    <h3>الاسم: <?php echo e($user->name); ?></h3>
			    <div class="table-responsive">
					<table class="table table-striped" style="direction: ltr;">
					  <tr>
					  	<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					    <td><?php echo e($name); ?></td>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					  </tr>
					  <tr>
					  	<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					    <td><?php echo e($value); ?></td>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					  </tr>
					</table>
			    </div>					
			  	<h3>المجموع النهائي: <?php echo e($user->total); ?></h3>
			  	<h3>النسبة المئوية: <?php echo e($user->percentage); ?>%</h3>
			</div>

	    <!-- jQuery -->
	    <script src="<?php echo e(URL::to('/js/jquery.js')); ?>"></script>

	    <!-- Bootstrap Core JavaScript -->
	    <script src="<?php echo e(URL::to('/js/bootstrap.min.js')); ?>"></script>
	</body>

</html>
